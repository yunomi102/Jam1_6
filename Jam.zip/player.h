#pragma once
#include"setting.h"

extern circle p;

void initplayer(void);
void updateplayer(void);
void drawplayer(void);