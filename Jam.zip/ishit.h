#pragma once
#include"setting.h"

void updateishit(void);
bool ishit(circle c1, circle c2);