#pragma once
#include"setting.h"

struct circle
{
	double x;
	double y;
	double vx;
	double vy;
	int r;
	int c;
	bool fill;
	bool enable;
	int hp;
	int damage;
	int time;
};