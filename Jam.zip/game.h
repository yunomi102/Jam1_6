#pragma once
#include"setting.h"

extern bool gameoverflag;

void initgame(void);
void updategame(void);
void drawgame(void);